-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i7a602.p.ssafy.io    Database: jangbo
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `salt`
--

DROP TABLE IF EXISTS `salt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `salt` (
  `id` int NOT NULL,
  `salt` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salt`
--

LOCK TABLES `salt` WRITE;
/*!40000 ALTER TABLE `salt` DISABLE KEYS */;
INSERT INTO `salt` VALUES (1,'$2a$10$2VIYHivEsxbCzzauETOUT.'),(2,'$2a$10$HrEop8bRQF0vfw1STZx2De'),(3,'$2a$10$kU3pIUjfarqstUk6l.zPx.'),(4,'$2a$10$LFgkR.u5NEPCVWXlrlC0vu'),(5,'$2a$10$5AklUT2PLBaZ2tfBX6YWYO'),(6,'$2a$10$lT5uteV3CQvcS5PX1BdSAe'),(7,'$2a$10$SJRf4UmMjLOvV9Ticb3tKu'),(8,'$2a$10$2Cj6rE7O6R7d/.OdHK0.7.'),(9,'$2a$10$mwY06HD21EcoSfOTFlCjXO'),(10,'$2a$10$QOdw8BCeLqq44XMI3N//ge'),(11,'$2a$10$7NpRAJg2Opy0IxuCYAbfM.'),(12,'$2a$10$mAEobv5YNAPA/XSVl/8fzO'),(13,'$2a$10$NUscEeGbxRxiUxtRrzcOvu'),(14,'$2a$10$Z5FI2v.h/jOWHebmDIGokO'),(15,'$2a$10$OkxaJpztR1Tfj2uSVeSZu.'),(16,'$2a$10$UfLKsRvh1AIiHJD4AQkxoe'),(17,'$2a$10$unbylTyyOApAJgqaIHdeoe'),(18,'$2a$10$N9tnaz/XzHhpq6NwL01qje'),(19,'$2a$10$LOfPIGIsyfgacqhEHL7Nje'),(20,'$2a$10$WSaAiU1E/pd.ZE9gZsToku'),(23,'$2a$10$aca9VYnVIhDYH0gtibJtle'),(24,'$2a$10$iDJ3IlYMLRzdEC.T/HMiie'),(25,'$2a$10$vvGb3nztQ2yVtIWIy/nyQO'),(26,'$2a$10$hIgT3zxHlMKb3WiOhxF6zu'),(27,'$2a$10$OD9JvRVa4FNRnUpSCmQ5e.'),(28,'$2a$10$/Pizo2Jm4oCXDi9BcTq5s.'),(29,'$2a$10$nVY5bQmb/mdJPaFukZupu.'),(30,'$2a$10$RKukpVU2eYZAmZGo7c0j4u'),(31,'$2a$10$ZVE95Awd3DNXUJ40dHOtW.'),(32,'$2a$10$r1igpQEVl8sowQgncAS0cu'),(33,'$2a$10$ylDLC2fBwGgXZ3J0bDaSEu'),(34,'$2a$10$xmJD6baZyztpAD9b9dc5S.'),(35,'$2a$10$nYRbdX2m/aYsjGap68Qx.O'),(36,'$2a$10$O4mxjsAdz1/F4KWBH1g8y.'),(37,'$2a$10$P2yXDSuhpHxow5uZHORyyu'),(38,'$2a$10$l7bT68/nK8XYc6BfnuV3Te'),(39,'$2a$10$m90WLqH9ZrmnKwPueWDugu'),(40,'$2a$10$yqv66vf/49neDCd1J0tDfu'),(41,'$2a$10$NHQ7qi1Rv/8CbR4Drfnl6e'),(42,'$2a$10$ZAmEygcgtCiCiQoktiAD..'),(44,'$2a$10$AnhwLQeD5EhXEe7lE/697.'),(45,'$2a$10$EakMs7hOSG4Hiaieel9USu'),(46,'$2a$10$EiS9P7Fmt6v.TuUuW7VPse'),(47,'$2a$10$H5OTmFrVw/MxYwf3v1Gqp.'),(48,'$2a$10$u5nvzUIwpAq4oKdv96mUUe'),(49,'$2a$10$wUlEszg/37SgFkLU1sIU1.'),(50,'$2a$10$jGmBW0C7/LiyxUssadS6ye'),(51,'$2a$10$5a0O7Y7B.qkuouVqIspVI.'),(52,'$2a$10$U8AH/ydLSWx27ppW9tmhse'),(53,'$2a$10$I4XmrEfdgYgV5N4.elxu7e'),(54,'$2a$10$jGBaaE6Zno8bIk88ZvWYAu'),(55,'$2a$10$nd34NTftlJF.K3keK8diFO'),(58,'$2a$10$qYhKoqluV4PIJit.oiK1n.'),(59,'$2a$10$S4tUycDn1M1tSObgMew31u'),(60,'$2a$10$VARhKE30P0heEPALIeMObO'),(61,'$2a$10$5R.ooPKJ10PMmMDYJVZcPu'),(62,'$2a$10$UzRAFd9XzhI0AEYb834wb.');
/*!40000 ALTER TABLE `salt` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 11:42:57
