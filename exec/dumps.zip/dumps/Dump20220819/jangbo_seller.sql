-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i7a602.p.ssafy.io    Database: jangbo
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `seller`
--

DROP TABLE IF EXISTS `seller`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seller` (
  `seller_no` int NOT NULL AUTO_INCREMENT,
  `business_number` varchar(15) DEFAULT NULL,
  `seller_id` varchar(20) DEFAULT NULL,
  `seller_name` varchar(15) DEFAULT NULL,
  `seller_phone` varchar(20) DEFAULT NULL,
  `seller_pwd` varchar(255) DEFAULT NULL,
  `salt_id` int DEFAULT NULL,
  PRIMARY KEY (`seller_no`),
  UNIQUE KEY `UK_ndn8y9sjuivq3j31m9vkd7t9c` (`business_number`),
  UNIQUE KEY `UK_1tdycvwhp77unqryb4bmcibdw` (`seller_id`),
  KEY `FKi90t7oumwbk7s6qcs2acojcve` (`salt_id`),
  CONSTRAINT `FKi90t7oumwbk7s6qcs2acojcve` FOREIGN KEY (`salt_id`) REFERENCES `salt` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seller`
--

LOCK TABLES `seller` WRITE;
/*!40000 ALTER TABLE `seller` DISABLE KEYS */;
INSERT INTO `seller` VALUES (4,'1234567812','testseller1','허설','01087544455','$2a$10$iDJ3IlYMLRzdEC.T/HMiietS6TPOuj1XcjGCeGKjcnKwLIU37Uxge',24),(5,'1111111111','1','판매자종선','010-0000-0000','$2a$10$hIgT3zxHlMKb3WiOhxF6zunciAGFsOARivG3.nTelTTus3R7ws6bC',26),(8,'1058754724','test_celler','갓찬국','01011111111','$2a$10$r1igpQEVl8sowQgncAS0cuXLAn0HmcgmFWxDNL0O75hcia/LcPFZi',32),(9,'8113700482','coach_seller','하와수','01022222222','$2a$10$ylDLC2fBwGgXZ3J0bDaSEulojNiXmkjqU.PnhUBPXpgE6HYFmONnK',33),(10,'5082601634','hyejinjjang','윤혜진','01077777777','$2a$10$xmJD6baZyztpAD9b9dc5S./OzAyml/J5jXV2DMloCz5R4yaY9DM5K',34),(11,'1371585284','kingjae','킹재승','01099999999','$2a$10$nYRbdX2m/aYsjGap68Qx.OGYgC5niplXbaAJ3EbFiG/TPlyY3GBOu',35),(12,'5415300680','jija1','박지원','01023332333','$2a$10$O4mxjsAdz1/F4KWBH1g8y.0TtASyC3e6Ia0e57CoIprHZUMNa3UyG',36),(13,'2390102210','ddong','이현규','01088888889','$2a$10$P2yXDSuhpHxow5uZHORyyuhC4Jh8yLZDHkFnteReK3TgVpibU7cCC',37),(14,'2111946762','sangbini95','임상빈','01078787878','$2a$10$l7bT68/nK8XYc6BfnuV3TelND2UNBPP4yjiIeOovEcY4iUwe62yuu',38),(15,'1193900793','gosutang0914','고수현','01034534233','$2a$10$m90WLqH9ZrmnKwPueWDuguGnGg0m93LNnOO20sdgJ5uEzWbK7mdAm',39),(16,'5555555500','qwerty','한싸피','01012341234','$2a$10$NHQ7qi1Rv/8CbR4Drfnl6eg6dHMoFLZL5lQ/q9v4qk42Ge4sBLWmK',41),(17,'1234340092','night','김준기','01054329786','$2a$10$ZAmEygcgtCiCiQoktiAD..xNrakQH29trmYOCGO2E39ek3ms28HbC',42),(19,'9999999999','seller1','박종선','010-0000-0000','$2a$10$AnhwLQeD5EhXEe7lE/697..tJ7ceB4RTAy.mNdWpJA.VTeXEjdWK.',44),(20,'1234562237','bindae','김준수','01095834222','$2a$10$EiS9P7Fmt6v.TuUuW7VPseQWNRozSXUSznL6.DEvC7LChN5EulyKy',46),(21,'1234235118','dong','dong','01001011212','$2a$10$H5OTmFrVw/MxYwf3v1Gqp.a6mqnuALYRokOWVJPxJ23FMo9mpZmkq',47),(22,'9726358269','hellossafy','김대한','01099938585','$2a$10$u5nvzUIwpAq4oKdv96mUUev3bvRwXOUfTJoNG40X43kka9XksV4rS',48),(23,'1234567890','luna','루나','010-9998-9202','$2a$10$jGmBW0C7/LiyxUssadS6yeOFv9M8MaYQoeX/uqoCH2Juv/pjtdxI.',50),(24,'6666666666','luna1','루나','010-9998-9202','$2a$10$5a0O7Y7B.qkuouVqIspVI.qO6fFfUUigXbBpgXAZxb5YJaJ9m0fdO',51),(25,'9494030385','azzzx','한대한','01095837248','$2a$10$U8AH/ydLSWx27ppW9tmhse/L864wJs9eGJIxzLlZkCWV/.RaB6w/O',52),(26,'1234987623','pokki','김국진','01099334584','$2a$10$jGBaaE6Zno8bIk88ZvWYAubkBRO0SI0cv94Tl7bOeQ1sa4UN1kI3S',54),(27,'1028112209','sss','김진호','01080801010','$2a$10$nd34NTftlJF.K3keK8diFOueWW0I39PnS01hwxMk4FFFPjSJDETZO',55),(30,'3333333333','luna2','루나','01099989202','$2a$10$qYhKoqluV4PIJit.oiK1n.oivCKOYqr2cCcomUe2FObC1CsAi5h7e',58),(31,'1234567897','luna3','루나','01099989202','$2a$10$S4tUycDn1M1tSObgMew31u5WFf1DUFxnJD84pa1CrjaBtOESfv7yi',59),(32,'9876543210','luna4','루나','01099989202','$2a$10$VARhKE30P0heEPALIeMObOc2lyXC8H/x5orr6mHGoBF9xwJMPFIWy',60),(33,'9888888888','luna5','루나','01099989202','$2a$10$5R.ooPKJ10PMmMDYJVZcPuEjeNyqJFR7Vxf1CRyeMiCxTc7kkEWDi',61);
/*!40000 ALTER TABLE `seller` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 11:42:54
