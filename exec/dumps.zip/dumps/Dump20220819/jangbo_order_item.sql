-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i7a602.p.ssafy.io    Database: jangbo
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `order_item`
--

DROP TABLE IF EXISTS `order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_item` (
  `order_item_no` int NOT NULL AUTO_INCREMENT,
  `count` int DEFAULT NULL,
  `item_name` varchar(255) DEFAULT NULL,
  `price` int DEFAULT NULL,
  `order_no` int DEFAULT NULL,
  PRIMARY KEY (`order_item_no`),
  KEY `FK64yctpiamtrlkbdp6lc626cy3` (`order_no`),
  CONSTRAINT `FK64yctpiamtrlkbdp6lc626cy3` FOREIGN KEY (`order_no`) REFERENCES `orders` (`order_no`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_item`
--

LOCK TABLES `order_item` WRITE;
/*!40000 ALTER TABLE `order_item` DISABLE KEYS */;
INSERT INTO `order_item` VALUES (1,10,'돼지 뒷다리 100g',10000,3),(2,1,'소 등심',10000,3),(3,4,'돼지 등심 100g',8000,4),(4,2,'소 등심',20000,4),(5,1,'덤) 소 등심',0,3),(6,1,'덤) 돼지 등심 100g',0,3),(7,4,'돼지 등심 100g',8000,5),(8,2,'소 등심',20000,5),(9,4,'돼지 등심 100g',8000,6),(10,2,'소 등심',20000,6),(11,4,'돼지 등심 100g',8000,7),(12,2,'소 등심',20000,7),(13,3,'돼지 뒷다리 100g',3000,8),(14,2,'돼지 삼겹살 100g',2000,8),(15,1,'덤) 돼지 뒷다리 100g',0,8),(16,1,'덤) 돼지 삼겹살 100g',0,8),(17,3,'돼지 삼겹살 100g',3000,9),(18,111,'소 등심',1110000,9),(19,1,'덤) 소 등심',0,9),(20,1,'돼지 뒷다리 100g',1000,10),(21,1,'돼지 뒷다리 100g',1000,11),(22,11,'돼지 뒷다리 100g',11000,13),(23,11,'돼지 뒷다리 100g',11000,14),(24,2,'돼지 삼겹살 100g',2000,14),(25,2,'돼지 삼겹살 100g',2000,15),(26,3,'돼지 삼겹살 100g',3000,16),(27,3,'돼지 삼겹살 100g',3000,17),(28,2,'돼지 삼겹살 100g',2000,17),(29,1,'돼지 뒷다리 100g',1000,18),(30,3,'돼지 등심 100g',6000,18),(31,1,'덤) 소 등심',0,18),(32,100,'빨간포션 1개',500,19),(33,1,'덤) 빨간포션 1개',0,19);
/*!40000 ALTER TABLE `order_item` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 11:42:56
