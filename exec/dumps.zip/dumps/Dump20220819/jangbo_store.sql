-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i7a602.p.ssafy.io    Database: jangbo
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `store`
--

DROP TABLE IF EXISTS `store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `store` (
  `store_no` int NOT NULL AUTO_INCREMENT,
  `store_addr` varchar(150) DEFAULT NULL,
  `store_category` varchar(30) DEFAULT NULL,
  `store_idx` tinyint NOT NULL,
  `store_img` varchar(150) DEFAULT NULL,
  `store_intro` varchar(300) DEFAULT NULL,
  `store_name` varchar(30) DEFAULT NULL,
  `store_phone` varchar(20) DEFAULT NULL,
  `store_subject` varchar(90) DEFAULT NULL,
  `market_no` int DEFAULT NULL,
  `seller_no` int DEFAULT NULL,
  PRIMARY KEY (`store_no`),
  KEY `FKn5r58xn4xiw212n8dp1rbxre6` (`market_no`),
  KEY `FKm60dqoq4ue15ro78lhmh515tc` (`seller_no`),
  CONSTRAINT `FKm60dqoq4ue15ro78lhmh515tc` FOREIGN KEY (`seller_no`) REFERENCES `seller` (`seller_no`),
  CONSTRAINT `FKn5r58xn4xiw212n8dp1rbxre6` FOREIGN KEY (`market_no`) REFERENCES `market` (`market_no`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `store`
--

LOCK TABLES `store` WRITE;
/*!40000 ALTER TABLE `store` DISABLE KEYS */;
INSERT INTO `store` VALUES (11,'두번째 골목의 편의점 옆 ','청과 ',1,'설이과일가게-4-20220818-1031786.jpg','안녕하세요 ','설이과일가게','0101234','반가워요 ',465,4),(26,'서울특별시 종로구 자하문로15길 18','청과',0,'default.png',NULL,'용인야채가게','01012341234',NULL,157,5),(27,'서울특별시 종로구 자하문로15길 18','마트',0,'default.png',NULL,'푸른마트','01012341235',NULL,157,8),(28,'서울특별시 종로구 자하문로15길 18','청과',0,'default.png',NULL,'백과과일','01012341236',NULL,157,9),(29,'서울특별시 종로구 자하문로15길 18','축산',0,'default.png',NULL,'고기백화점','01012341237',NULL,157,10),(30,'서울특별시 종로구 자하문로15길 18','농/수산물',0,'default.png',NULL,'우리상회','01012342348',NULL,157,11),(31,'서울특별시 종로구 자하문로15길 18','축산',0,'default.png',NULL,'통인축산','01023456787',NULL,157,12),(32,'서울특별시 종로구 자하문로15길 18','음식점',0,'default.png',NULL,'세종식당','01087465647',NULL,157,13),(33,'서울특별시 종로구 자하문로15길 18','방앗간',1,'default.png','테스트방','부여떡방아간','01012344545','테스트방입니다 ',157,14),(34,'서울특별시 종로구 자하문로15길 18','카페',0,'default.png',NULL,'러브마들렌','01078734636',NULL,157,15),(35,'점포 157번','축산',1,'default.png','1234','맛있는정육점','01012341234','1234',157,16),(36,'24번 점포','채소/청과',1,'default.png',NULL,'싱싱청과물','0311236859',NULL,1,17),(37,'어딘가','그 외 기타',1,'종선이네 잡화상점-19-20220818-2241754.jpg','종선이네 가게','종선이네 잡화상점','010-0000-0000','놀러오세요!!',1,19),(38,'49번 점포','음식점',1,'우리집빈대떡-20-20220818-2313745.jfif',NULL,'우리집빈대떡','022341245',NULL,157,20),(49,'12번 점포','음식점',1,'토끼굴-21-20220819-0044524.jfif',NULL,'토끼굴','024245399',NULL,157,21),(50,'88번 점포','그 외 기타',0,'공구나라 망치공주-22-20220819-0057770.jfif',NULL,'공구나라 망치공주','028220909',NULL,157,22),(51,'어딘가','그 외 기타',1,'luna1의 상점-24-20220819-0735509.png','급처중입니다','루나의 잡화상점','010-9998-9202','포션 팔아요@@@@@@@@@@@@@@@@ ',157,24),(52,'점포 24번','음식점',1,'오빠네 요즘 떡볶이-26-20220819-0805183.jfif','00','오빠네 요즘 떡볶이','01042429876','00',157,26),(53,'어딘가','그 외 기타',0,'default.png',NULL,'루나의 잡화상점','01099989202',NULL,157,23),(54,'어딘가','그 외 기타',0,'default.png',NULL,'루나의 잡화상점','01099989202',NULL,157,30),(55,'어딘가','그 외 기타',0,'루나의 잡화상점-31-20220819-0916947.png',NULL,'루나의 잡화상점','01099989202',NULL,157,31),(56,'어딘가','그 외 기타',0,'루나의 잡화상점-32-20220819-0922201.png',NULL,'루나의 잡화상점','01099989202',NULL,157,32),(57,'어딘가','그 외 기타',1,'루나의 잡화상점-33-20220819-0924710.png','급처중입니다5','루나의 잡화상점','01099989202','포션 팔아요@@@@@@@@@@@@@@@@',157,33);
/*!40000 ALTER TABLE `store` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 11:42:58
