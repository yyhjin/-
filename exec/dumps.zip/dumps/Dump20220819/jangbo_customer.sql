-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i7a602.p.ssafy.io    Database: jangbo
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `customer_no` int NOT NULL AUTO_INCREMENT,
  `customer_addr` varchar(150) DEFAULT NULL,
  `customer_id` varchar(20) DEFAULT NULL,
  `customer_index` tinyint NOT NULL,
  `customer_name` varchar(15) DEFAULT NULL,
  `customer_nickname` varchar(30) DEFAULT NULL,
  `customer_phone` varchar(20) DEFAULT NULL,
  `customer_pwd` varchar(255) DEFAULT NULL,
  `salt_id` int DEFAULT NULL,
  PRIMARY KEY (`customer_no`),
  UNIQUE KEY `UK_jt63q2suy91q2uch0ll9wcxx5` (`customer_id`),
  KEY `FKxbod49p27v9okqjv56meht9n` (`salt_id`),
  CONSTRAINT `FKxbod49p27v9okqjv56meht9n` FOREIGN KEY (`salt_id`) REFERENCES `salt` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (15,'인천 미추홀구 토금남로 55 9동 201호 (용현동, 한양아파트)','hseol',1,'허설','새벽의이슬','01076436603','$2a$10$UfLKsRvh1AIiHJD4AQkxoeXwvq/wUBNhRAYhW1gs7ZpG.EsU68h9a',16),(16,'서울 종로구 평창동 211-5 201호 ','rhshfo8282',1,'김윤지','평창동불주먹','010-9945-7004','$2a$10$N9tnaz/XzHhpq6NwL01qjeswcAR2t7dR7IRYWjkEuYXYH98rY3Quu',18),(18,'123 123 123','dlrudan',1,'경무','dlrudan','123','$2a$10$WSaAiU1E/pd.ZE9gZsTokuUAbxkrvFXaEMa.0lOxYMeNWew4jfjKS',20),(21,'서울 강남구 테헤란로 212 123 (역삼동)','dlrudan77',1,'경무','dlrudan','01041794641','$2a$10$aca9VYnVIhDYH0gtibJtlexv5AeX2nhSydB5DHThil8R5MOLza/FG',23),(22,'서울 광진구 구의강변로 42 어딘가 (구의동, 구의동강변우성아파트)','1',1,'박종선','종선','010-0000-0000','$2a$10$vvGb3nztQ2yVtIWIy/nyQOwdjShJLwNZybhJrxRayaC7FAygAStKy',25),(24,'서울 강남구 테헤란로 212 멀티캠퍼스 (역삼동)','test_customer',1,'갓찬국','갓찬국','01012345678','$2a$10$RKukpVU2eYZAmZGo7c0j4ufwMjueSn.6m1XzsqpTy8SxjrXMQgDzC',30),(25,'서울 강남구 테헤란로 212 멀티캠퍼스 17층 (역삼동)','coach_customer',1,'하와수','코치코치얍','01012345678','$2a$10$ZVE95Awd3DNXUJ40dHOtW.rTR.Eswc0qdw.Egi2Q0Y.xOdu.o3AE2',31),(26,'서울 강남구 테헤란로 212 14층 (역삼동)','ssafy96',1,'김수한무','사과가 조아요','01012349876','$2a$10$yqv66vf/49neDCd1J0tDfu0ZmNk/bKjdFIO0YX/Z6z/zEqRAZlQgq',40),(27,'인천 미추홀구 연남로 35 6층  (관교동)','yyy',1,'윤혜진','자고싶다','01072905516','$2a$10$EakMs7hOSG4Hiaieel9USucQcwHRdn8HRx3kbONjU3JqHBFRGN322',45),(28,'서울 강동구 양재대로123길 7 1234 (천호동, 강동그랑시아)','asdfasdf',1,'adassfadfasd','asdf','01010101010','$2a$10$wUlEszg/37SgFkLU1sIU1.egMqbTtPBaZeeGaVpNNKBlBMs.wsl1m',49),(29,'서울 강남구 강남대로66길 14  (역삼동)','hoho',1,'박대기','호우','01093588855','$2a$10$I4XmrEfdgYgV5N4.elxu7e69Mh9P67Bmk.D0ntBku14UP7Dh8irOK',53),(30,'인천 미추홀구 토금남로 55  (용현동, 한양아파트)','test602',1,'허싸피','공통프로젝트힘들어','01076436603','$2a$10$UzRAFd9XzhI0AEYb834wb.lTRPKZR6o3LsUUBeuQAR5c2FW/Y9srq',62);
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 11:42:56
